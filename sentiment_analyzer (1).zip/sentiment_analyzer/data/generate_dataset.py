"""
generate_dataset.py
--------------------
Builds a labeled customer-review dataset for sentiment analysis
(Positive / Negative / Neutral).

Why generated instead of downloaded:
This environment has no internet access from the code sandbox, so instead of
downloading a dataset (e.g. Amazon/Yelp reviews), we programmatically build a
realistic dataset using common real-world review patterns across several
product categories (electronics, clothing, food delivery, software, home
goods), with randomized product names/details so messages aren't repeats.

If you have internet access, you can swap this out for a real dataset (e.g.
Kaggle's "Amazon Product Reviews" or "Yelp Reviews") by replacing the CSV
produced here -- the rest of the pipeline (preprocess.py, train.py) expects
a CSV with columns:
    label    (positive / negative / neutral)
    review   (raw text)
"""

import random
import csv
import os

random.seed(42)

# Always write next to this script's own data/ folder, regardless of which
# directory the script is *run* from (fixes path errors when run in Colab).
OUT_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "reviews_dataset.csv")

products = [
    "wireless headphones", "coffee maker", "running shoes", "laptop stand",
    "backpack", "desk lamp", "blender", "yoga mat", "bluetooth speaker",
    "office chair", "water bottle", "phone case", "air fryer", "notebook set",
    "gaming mouse", "electric kettle", "winter jacket", "board game",
    "skincare cream", "travel pillow",
]

# ---------------------------------------------------------------------------
# POSITIVE templates
# ---------------------------------------------------------------------------
positive_templates = [
    "This {product} exceeded my expectations, absolutely love it!",
    "Great quality {product}, works perfectly and arrived early.",
    "Best {product} I've bought this year, highly recommend to everyone.",
    "The {product} is amazing, exactly as described and super comfortable.",
    "Fantastic {product}! Fast shipping and excellent customer service too.",
    "I'm so happy with this {product}, it's durable and looks great.",
    "Five stars for this {product}, works like a charm every time.",
    "Really impressed with the {product}, worth every penny.",
    "The {product} is well made and super easy to use, love it!",
    "Excellent {product}, better quality than I expected for the price.",
    "This {product} is a game changer, I use it every single day now.",
    "Perfect {product}, exactly what I needed. Will buy again!",
    "Outstanding {product}, the build quality is top notch.",
    "So glad I purchased this {product}, it works flawlessly.",
    "The {product} arrived quickly and works better than expected.",
]

# ---------------------------------------------------------------------------
# NEGATIVE templates
# ---------------------------------------------------------------------------
negative_templates = [
    "This {product} broke after just two days, very disappointed.",
    "Terrible quality {product}, would not recommend to anyone.",
    "The {product} arrived damaged and customer service was unhelpful.",
    "Waste of money, this {product} stopped working within a week.",
    "Very poor {product}, nothing like the pictures shown online.",
    "I regret buying this {product}, it's cheaply made and flimsy.",
    "The {product} doesn't work as advertised, total disappointment.",
    "Awful experience, the {product} was defective right out of the box.",
    "This {product} is overpriced for such low quality, avoid it.",
    "Extremely unhappy with this {product}, it feels like a cheap knockoff.",
    "The {product} malfunctioned immediately, requesting a refund.",
    "Poor packaging led to a damaged {product}, very frustrating.",
    "This {product} is uncomfortable and not worth the price at all.",
    "Would give zero stars if I could, this {product} is useless.",
    "The {product} stopped functioning after minimal use, big letdown.",
]

# ---------------------------------------------------------------------------
# NEUTRAL templates (mixed, mediocre, or purely factual reviews)
# ---------------------------------------------------------------------------
neutral_templates = [
    "The {product} is okay, does the job but nothing special.",
    "Average {product}, works fine but the design could be better.",
    "It's a decent {product} for the price, though not outstanding.",
    "The {product} arrived on time, packaging was standard.",
    "This {product} works as expected, no major complaints.",
    "Not bad, not great -- the {product} is just okay overall.",
    "The {product} does what it says, but the material feels average.",
    "It's a fine {product}, though I probably won't repurchase.",
    "The {product} met my basic expectations, nothing more nothing less.",
    "Reasonably priced {product}, performance is acceptable for daily use.",
    "The {product} looks nice but functionality is just average.",
    "It works, though the {product} takes a bit of getting used to.",
    "The {product} is fine for occasional use, wouldn't call it exceptional.",
    "Mediocre {product}, some features are useful, others feel unnecessary.",
    "The {product} is exactly average -- neither impressive nor bad.",
]

# "Hard" cross-over examples that mix positive/negative vocabulary in an
# ambiguous way -- makes the classification task realistic instead of trivial.
hard_positive = [
    "I was skeptical about this {product} at first, but it turned out great!",
    "Not the cheapest {product} out there, but absolutely worth it.",
    "Took a while to arrive, but the {product} itself is fantastic.",
    "Not bad at all -- actually this {product} works really well.",
    "A bit pricey, but honestly this {product} is great value long term.",
    "Small learning curve, but once I got used to the {product} I loved it.",
    "Packaging was a little rough but the {product} itself works perfectly.",
    "It's not perfect, but this {product} genuinely made my life easier.",
]
hard_negative = [
    "The {product} looks nice, but it broke within a week -- disappointing.",
    "Customer service was polite, but the {product} itself is defective.",
    "Packaging was nice, shame the {product} doesn't actually work well.",
    "It's a good idea for a {product}, but the execution is honestly poor.",
    "Looks great on paper, but this {product} just doesn't perform well.",
    "Nice design, terrible durability -- the {product} fell apart fast.",
    "I wanted to like this {product}, but it's just not good quality.",
    "Great price, but you get what you pay for with this {product}.",
]
hard_neutral = [
    "The {product} has some good points and some bad points, hard to say.",
    "I neither love nor hate this {product}, it's just there.",
    "Some days the {product} works great, other days not so much.",
    "Good in some ways, bad in others -- this {product} is a mixed bag.",
    "The {product} isn't bad, but it isn't great either, just average.",
    "Decent build but average performance, this {product} is middle of the road.",
    "Some nice features, some annoying flaws in this {product}, balances out.",
    "Works okay most of the time, this {product} is neither good nor bad.",
]

fillers = ["", " Thanks.", " Would consider again.", " Just my honest opinion.", ""]


def make_review(templates):
    t = random.choice(templates)
    product = random.choice(products)
    review = t.format(product=product)
    review = review + random.choice(fillers)
    return review.strip()


N_PER_CLASS = 500

rows = []
seen = set()


def add_unique(label, templates, n):
    count = 0
    tries = 0
    while count < n and tries < n * 30:
        tries += 1
        msg = make_review(templates)
        key = (label, msg)
        if key in seen:
            continue
        seen.add(key)
        rows.append((label, msg))
        count += 1


add_unique("positive", positive_templates + hard_positive, N_PER_CLASS)
add_unique("negative", negative_templates + hard_negative, N_PER_CLASS)
add_unique("neutral", neutral_templates + hard_neutral, N_PER_CLASS)

random.shuffle(rows)

# Inject a small amount of label noise (~6%) to mimic real-world annotation
# disagreement -- without this, the templated text is too clean and every
# model scores a perfect 1.0, which isn't a realistic or useful comparison.
NOISE_RATE = 0.06
all_labels = ["positive", "negative", "neutral"]
noisy_rows = []
for label, msg in rows:
    if random.random() < NOISE_RATE:
        other_labels = [l for l in all_labels if l != label]
        label = random.choice(other_labels)
    noisy_rows.append((label, msg))
rows = noisy_rows

with open(OUT_PATH, "w", newline="", encoding="utf-8") as f:
    writer = csv.writer(f)
    writer.writerow(["label", "review"])
    writer.writerows(rows)

print(f"Dataset written: {len(rows)} rows "
      f"(positive={sum(1 for r in rows if r[0]=='positive')}, "
      f"negative={sum(1 for r in rows if r[0]=='negative')}, "
      f"neutral={sum(1 for r in rows if r[0]=='neutral')})")
