"""
streamlit_app.py
-----------------
Bonus interactive UI for the Customer Review Sentiment Analyzer.

Run locally with:
    pip install streamlit scikit-learn pandas matplotlib
    streamlit run streamlit_app.py

(Make sure you've run `python src/train.py` first so the models/*.pkl and
outputs/wordcloud_*.png files exist.)
"""

import os
import pickle

import streamlit as st

BASE = os.path.dirname(os.path.abspath(__file__))
MODELS_DIR = os.path.join(BASE, "models")
OUTPUTS_DIR = os.path.join(BASE, "outputs")

import sys
sys.path.append(os.path.join(BASE, "src"))
from preprocess import preprocess  # noqa: E402

LABELS = ["negative", "neutral", "positive"]
EMOJI = {"negative": "😠", "neutral": "😐", "positive": "😊"}


@st.cache_resource
def load_artifacts():
    with open(os.path.join(MODELS_DIR, "vectorizer.pkl"), "rb") as f:
        vectorizer = pickle.load(f)
    models = {}
    for name, fname in [
        ("Naive Bayes", "naive_bayes_model.pkl"),
        ("Logistic Regression", "logistic_regression_model.pkl"),
        ("Linear SVM", "svm_model.pkl"),
    ]:
        path = os.path.join(MODELS_DIR, fname)
        if os.path.exists(path):
            with open(path, "rb") as f:
                models[name] = pickle.load(f)
    best_name = "Naive Bayes"
    best_path = os.path.join(MODELS_DIR, "best_model_name.txt")
    if os.path.exists(best_path):
        with open(best_path) as f:
            best_name = f.read().strip()
    return vectorizer, models, best_name


st.set_page_config(page_title="Review Sentiment Analyzer", page_icon="🛍️", layout="centered")
st.title("🛍️ Customer Review Sentiment Analyzer")
st.markdown("Enter a customer review below to check its sentiment: **Positive**, **Negative**, or **Neutral**.")

vectorizer, models, best_name = load_artifacts()

if not models:
    st.error(
        "No trained models found. Please run `python src/train.py` first "
        "to generate the model files in the `models/` folder."
    )
    st.stop()

model_choice = st.selectbox(
    "Choose a model", list(models.keys()),
    index=list(models.keys()).index(best_name) if best_name in models else 0,
)

review = st.text_area("Review", height=120, placeholder="Type or paste a customer review here...")

if st.button("Analyze Sentiment", type="primary"):
    if not review.strip():
        st.warning("Please enter a review first.")
    else:
        cleaned = preprocess(review)
        X = vectorizer.transform([cleaned])
        model = models[model_choice]
        pred = model.predict(X)[0]
        label = LABELS[pred]

        if label == "positive":
            st.success(f"{EMOJI[label]} This review looks **POSITIVE**.")
        elif label == "negative":
            st.error(f"{EMOJI[label]} This review looks **NEGATIVE**.")
        else:
            st.info(f"{EMOJI[label]} This review looks **NEUTRAL**.")

        if hasattr(model, "predict_proba"):
            proba = model.predict_proba(X)[0]
            st.caption(
                f"Confidence — Negative: {proba[0]*100:.1f}% | "
                f"Neutral: {proba[1]*100:.1f}% | Positive: {proba[2]*100:.1f}%"
            )

        with st.expander("See cleaned/preprocessed text used by the model"):
            st.code(cleaned or "(empty after cleaning)")

st.divider()
st.subheader("📊 Word Clouds by Sentiment (bonus)")
tabs = st.tabs(["Positive", "Negative", "Neutral"])
for tab, label in zip(tabs, ["positive", "negative", "neutral"]):
    with tab:
        img_path = os.path.join(OUTPUTS_DIR, f"wordcloud_{label}.png")
        if os.path.exists(img_path):
            st.image(img_path, use_column_width=True)
        else:
            st.caption("Run `python src/train.py` to generate this word cloud.")

st.caption(
    "Model trained on a labeled dataset of customer reviews using TF-IDF "
    "vectorization. Try switching models above to compare predictions."
)
