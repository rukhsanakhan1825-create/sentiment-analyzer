"""
train.py
--------
End-to-end pipeline:
  1. Load dataset
  2. Clean & preprocess text
  3. TF-IDF vectorization (feature extraction)
  4. Train Multinomial Naive Bayes + Logistic Regression (+ bonus Linear SVM)
  5. Evaluate & compare (accuracy, precision, recall, F1 -- macro-averaged
     since this is a 3-class problem), confusion matrix
  6. Test on new unseen reviews
  7. Save trained model + vectorizer for the Streamlit app
"""

import sys
import os
import pickle

import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.linear_model import LogisticRegression
from sklearn.svm import LinearSVC
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    confusion_matrix,
)

sys.path.append(os.path.dirname(__file__))
from preprocess import preprocess  # noqa: E402

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_PATH = os.path.join(BASE, "data", "reviews_dataset.csv")
MODELS_DIR = os.path.join(BASE, "models")
OUT_DIR = os.path.join(BASE, "outputs")

LABELS = ["negative", "neutral", "positive"]
LABEL_TO_NUM = {l: i for i, l in enumerate(LABELS)}


def load_data():
    df = pd.read_csv(DATA_PATH)
    df = df.dropna(subset=["label", "review"]).drop_duplicates()
    df["label_num"] = df["label"].map(LABEL_TO_NUM)
    return df


def plot_confusion(cm, model_name, filename):
    fig, ax = plt.subplots(figsize=(5, 4.5))
    im = ax.imshow(cm, cmap="Blues")
    ax.set_xticks(range(len(LABELS))); ax.set_xticklabels(LABELS, rotation=20)
    ax.set_yticks(range(len(LABELS))); ax.set_yticklabels(LABELS)
    ax.set_xlabel("Predicted")
    ax.set_ylabel("Actual")
    ax.set_title(f"Confusion Matrix — {model_name}")
    for i in range(len(LABELS)):
        for j in range(len(LABELS)):
            ax.text(j, i, str(cm[i, j]), ha="center", va="center",
                     color="white" if cm[i, j] > cm.max() / 2 else "black",
                     fontsize=13, fontweight="bold")
    fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
    fig.tight_layout()
    fig.savefig(os.path.join(OUT_DIR, filename), dpi=150)
    plt.close(fig)


def simple_wordcloud(word_freq: dict, title: str, filename: str, color: str):
    """A lightweight, dependency-free 'word cloud' built with matplotlib
    (no internet access available to install the `wordcloud` package)."""
    import random as _r
    _r.seed(0)
    fig, ax = plt.subplots(figsize=(7, 5))
    ax.axis("off")
    ax.set_title(title, fontsize=14)
    items = sorted(word_freq.items(), key=lambda x: -x[1])[:35]
    if not items:
        ax.text(0.5, 0.5, "(not enough words)", ha="center", va="center")
    else:
        max_f = items[0][1]
        for word, freq in items:
            size = 10 + 40 * (freq / max_f)
            x, y = _r.uniform(0.05, 0.95), _r.uniform(0.05, 0.95)
            alpha = 0.5 + 0.5 * (freq / max_f)
            ax.text(x, y, word, fontsize=size, color=color, alpha=alpha,
                     ha="center", va="center",
                     transform=ax.transAxes,
                     rotation=_r.choice([0, 0, 0, 90]))
    fig.tight_layout()
    fig.savefig(os.path.join(OUT_DIR, filename), dpi=150)
    plt.close(fig)


def evaluate(name, y_true, y_pred):
    acc = accuracy_score(y_true, y_pred)
    prec = precision_score(y_true, y_pred, average="macro", zero_division=0)
    rec = recall_score(y_true, y_pred, average="macro", zero_division=0)
    f1 = f1_score(y_true, y_pred, average="macro", zero_division=0)
    cm = confusion_matrix(y_true, y_pred, labels=[0, 1, 2])
    print(f"\n=== {name} ===")
    print(f"Accuracy          : {acc:.4f}")
    print(f"Precision (macro) : {prec:.4f}")
    print(f"Recall (macro)    : {rec:.4f}")
    print(f"F1 Score (macro)  : {f1:.4f}")
    print(f"Confusion Matrix (rows/cols order = {LABELS}):")
    print(cm)
    return {"model": name, "accuracy": acc, "precision": prec,
            "recall": rec, "f1": f1, "cm": cm}


def main():
    os.makedirs(MODELS_DIR, exist_ok=True)
    os.makedirs(OUT_DIR, exist_ok=True)

    print("Loading dataset...")
    df = load_data()
    print(f"Total reviews: {len(df)}  "
          f"(positive={sum(df.label=='positive')}, "
          f"negative={sum(df.label=='negative')}, "
          f"neutral={sum(df.label=='neutral')})")

    print("Cleaning & preprocessing text...")
    df["clean_review"] = df["review"].apply(preprocess)

    X_train_text, X_test_text, y_train, y_test = train_test_split(
        df["clean_review"], df["label_num"],
        test_size=0.2, random_state=42, stratify=df["label_num"]
    )

    print("Extracting features with TF-IDF...")
    vectorizer = TfidfVectorizer(max_features=2000, ngram_range=(1, 1))
    X_train = vectorizer.fit_transform(X_train_text)
    X_test = vectorizer.transform(X_test_text)

    results = []

    # --- Model 1: Multinomial Naive Bayes ---
    nb = MultinomialNB()
    nb.fit(X_train, y_train)
    res_nb = evaluate("Naive Bayes", y_test, nb.predict(X_test))
    results.append(res_nb)
    plot_confusion(res_nb["cm"], "Naive Bayes", "confusion_matrix_naive_bayes.png")

    # --- Model 2: Logistic Regression ---
    lr = LogisticRegression(max_iter=1000)
    lr.fit(X_train, y_train)
    res_lr = evaluate("Logistic Regression", y_test, lr.predict(X_test))
    results.append(res_lr)
    plot_confusion(res_lr["cm"], "Logistic Regression", "confusion_matrix_logistic_regression.png")

    # --- Bonus Model 3: Linear SVM ---
    svm = LinearSVC()
    svm.fit(X_train, y_train)
    res_svm = evaluate("Linear SVM", y_test, svm.predict(X_test))
    results.append(res_svm)
    plot_confusion(res_svm["cm"], "Linear SVM", "confusion_matrix_svm.png")

    # --- Comparison chart ---
    metrics_df = pd.DataFrame(results)[["model", "accuracy", "precision", "recall", "f1"]]
    metrics_df.to_csv(os.path.join(OUT_DIR, "model_comparison.csv"), index=False)
    print("\n=== Model Comparison ===")
    print(metrics_df.to_string(index=False))

    fig, ax = plt.subplots(figsize=(7, 4.5))
    metrics_df.set_index("model").plot(kind="bar", ax=ax, rot=15)
    ax.set_ylabel("Score")
    ax.set_ylim(0, 1.05)
    ax.set_title("Model Performance Comparison")
    ax.legend(loc="lower right")
    fig.tight_layout()
    fig.savefig(os.path.join(OUT_DIR, "model_comparison.png"), dpi=150)
    plt.close(fig)

    # --- Pick best model by F1 ---
    best = max(results, key=lambda r: r["f1"])
    best_model = {"Naive Bayes": nb, "Logistic Regression": lr, "Linear SVM": svm}[best["model"]]
    print(f"\nBest model by F1: {best['model']} (F1={best['f1']:.4f}) -> saved as default")

    with open(os.path.join(MODELS_DIR, "vectorizer.pkl"), "wb") as f:
        pickle.dump(vectorizer, f)
    with open(os.path.join(MODELS_DIR, "naive_bayes_model.pkl"), "wb") as f:
        pickle.dump(nb, f)
    with open(os.path.join(MODELS_DIR, "logistic_regression_model.pkl"), "wb") as f:
        pickle.dump(lr, f)
    with open(os.path.join(MODELS_DIR, "svm_model.pkl"), "wb") as f:
        pickle.dump(svm, f)
    with open(os.path.join(MODELS_DIR, "best_model.pkl"), "wb") as f:
        pickle.dump(best_model, f)
    with open(os.path.join(MODELS_DIR, "best_model_name.txt"), "w") as f:
        f.write(best["model"])

    # --- Bonus: Word cloud visualization per sentiment class ---
    print("\nGenerating word clouds per sentiment class...")
    from collections import Counter
    colors = {"positive": "green", "negative": "crimson", "neutral": "steelblue"}
    for label in LABELS:
        texts = df.loc[df["label"] == label, "clean_review"]
        freq = Counter(" ".join(texts).split())
        simple_wordcloud(freq, f"Most common words — {label.title()} reviews",
                          f"wordcloud_{label}.png", colors[label])

    # --- Test with brand-new example reviews ---
    new_reviews = [
        "This laptop stand is fantastic, sturdy and easy to set up!",
        "Terrible experience, the blender stopped working after one use.",
        "It's an okay backpack, does the job but nothing special.",
        "Absolutely love this coffee maker, best purchase this year!",
        "The jacket ripped on the first wear, very disappointed.",
        "The mouse works fine, average quality for the price.",
    ]
    print("\n=== Testing on new, unseen reviews ===")
    cleaned_new = [preprocess(r) for r in new_reviews]
    X_new = vectorizer.transform(cleaned_new)
    preds_best = best_model.predict(X_new)
    for review, pred in zip(new_reviews, preds_best):
        print(f"[{LABELS[pred].upper():8s}] {review}")

    print(f"\nAll outputs saved to: {OUT_DIR}")
    print(f"All models saved to : {MODELS_DIR}")


if __name__ == "__main__":
    main()
