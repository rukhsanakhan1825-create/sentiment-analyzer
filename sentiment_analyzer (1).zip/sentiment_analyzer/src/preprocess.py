"""
preprocess.py
-------------
Text cleaning utilities for the sentiment analyzer.

We avoid nltk.download() (no internet in this environment) and instead use a
small built-in English stopword list -- a standard, lightweight approach for
short review-style text.
"""

import re
import string

STOPWORDS = set("""
a an the and or but if while is are was were be been being to of in on for
with as at by from this that these those it its it's i you he she we they
me him her us them my your his our their am do does did doing have has had
having will would shall should can could may might must now just so than
too very
""".split())


def clean_text(text: str) -> str:
    """Lowercase, strip URLs/numbers/punctuation, collapse whitespace."""
    text = text.lower()
    text = re.sub(r"http\S+|www\.\S+", " ", text)          # URLs
    text = re.sub(r"\d+", " ", text)                        # digits
    text = text.translate(str.maketrans("", "", string.punctuation))
    text = re.sub(r"\s+", " ", text).strip()
    return text


def remove_stopwords(text: str) -> str:
    tokens = [w for w in text.split() if w not in STOPWORDS and len(w) > 1]
    return " ".join(tokens)


def preprocess(text: str) -> str:
    return remove_stopwords(clean_text(text))


if __name__ == "__main__":
    sample = "This product is NOT worth it, it broke after 2 days!!"
    print("raw:      ", sample)
    print("cleaned:  ", clean_text(sample))
    print("no-stop:  ", preprocess(sample))
